import React from 'react';
import './Write1.css';

export default function Write() {
  return (
    <div className="write">
      <form className="writeForm">
        <div className="writeFormGroup">
          <label htmlFor="fileinput">File ADD:</label>
          <input type="file" id="fileinput" />  <br/>
          <input type="text" placeholder="Title" className="writeInput" autoFocus={true} />
        </div>
        <div className="writeFormGroup">
          <textarea className="writeInput" placeholder="Write about You .........." />
        </div>
        <button className="writeSubmit">Submit</button>
      </form>
    </div>
  );
}
